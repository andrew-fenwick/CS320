package taskTest;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import taskPackage.Task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


class TaskTest {
	
	void testTask1() {
		Task Task = new Task("12345", "Andrew Fenwick", "SNHU Comp Sci Student");
		assertTrue(Task.getTaskID().equals("12345"));
		assertTrue(Task.getTaskName().equals("Andrew Fenwick"));
		assertTrue(Task.getTaskScript().equals("SNHU Comp Sci Student"));		
	}

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
