package appointmentTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AppointmentTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
