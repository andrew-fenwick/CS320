package taskPackage;


public class Task {
	
	private String taskID;
    private String taskName;
    private String taskScript;
	

	public Task(String taskID, String taskName, String taskScript) {
		
		if(taskID == null || taskID.length()>10) {
            throw new IllegalArgumentException("Invalid Task ID");
        }
        if(taskName == null || taskName.length()>20) {
            throw new IllegalArgumentException("Invalid Name");
        }
        if(taskScript == null || taskScript.length()>50) {
            throw new IllegalArgumentException("Invalid Description");
        }
	}
	
    
	public String taskID() {
        return taskID;
    }

    public String taskName() {
        return taskName;
    }

    public String taskScript() {
        return taskScript;
    }


}

