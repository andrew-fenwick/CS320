package contactTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import contactPackage.contactPhoneClass;

class testContactPhone {
	@Test
	void testContactPhone1() {
		contactPhoneClass contactPhoneClass = new contactPhoneClass("12345", "Sally", "Jones", "8001234567", "123 Main St, Springfield, NJ, 12345");
		assertTrue(contactPhoneClass.getPhoneID().equals("12345"));
		assertTrue(contactPhoneClass.getFirstName().equals("Sally"));
		assertTrue(contactPhoneClass.getLastName().equals("Jones"));
		assertTrue(contactPhoneClass.getPhoneNumber().equals("8001234567"));
		assertTrue(contactPhoneClass.getAddress().equals("123 Main St, Springfield, NJ, 12345"));
	}

	@Test
	void test() {
		fail("Not yet implemented");
	}

}