package contactServicePackage;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import contactPackage.contactPhoneClass;

public class contactService {

	private String uniqueID;
	private String freshUniqueID;
	private List<contactPhoneClass> contactList = new ArrayList<>(); {
		uniqueID = UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
	}
	
	private contactPhoneClass findContact(String phoneID) throws Exception {
		int index = 0;
		while (index < contactList.size()) {
			if (phoneID.equals(contactList.get(index).getPhoneID())) {
				return contactList.get(index);
			}
			index++;
		}
		throw new Exception("Unable to Process");
	}
	
	private String freshUniqueID() {
		return uniqueID = UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
	}
	
	protected List<contactPhoneClass> getContactList() {
		return contactList;
	}
	
	
	
	public void newContact() {
		contactPhoneClass contact = new contactPhoneClass(freshUniqueID());
		contactList.add(contact);
		
	}
	
	public void newContact(String firstName) {
		contactPhoneClass contact = new contactPhoneClass(freshUniqueID(), firstName);
		contactList.add(contact);
	}
	
	public void newContact(String firstName, String lastName) {
		contactPhoneClass contact = new contactPhoneClass(newUniqueID(), firstName, lastName);
		contactList.add(contact);
	}
	
	public void newContact(String firstName, String lastName, String phoneNumber) {
		contactPhoneClass contact = new contactPhoneClass(freshUniqueID(), firstName, lastName, phoneNumber);
		contactList.add(contact);
	}
	
	public void newContact(String firstName, String lastName, String phoneNumber, String Address) {
		contactPhoneClass contact = new contactPhoneClass(freshUniqueID(), firstName, lastName, phoneNumber, Address);
		contactList.add(contact);
	}
	
	public void deleteContact(String contactID) throws Exception {
		contactList.remove(findContact(contactID));
	}
	
	public void updateFirstName(String contactID, String firstName) throws Exception {
		findContact(contactID).updateFirstName(firstName);
	}
	
	public void updateLastName(String contactID, String lastName) throws Exception {
		findContact(contactID).updateLastName(lastName);
	}

	public void updatePhoneNumber(String contactID, String phoneNumber) throws Exception {
		findContact(contactID).updatePhoneNumber(phoneNumber);
	}
	
	public void updateAddress(String contactID, String Address) throws Exception {
		findContact(contactID).updateAddress(Address);
	}
}
