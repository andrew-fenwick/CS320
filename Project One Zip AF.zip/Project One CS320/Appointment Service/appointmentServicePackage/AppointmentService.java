package appointmentServicePackage;

//included everything needed for dates 
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.Date;
import appointmentPackage.Appointment;

public class AppointmentService {

//first to set up the strings needed 
	private String uniqueID;
	private String freshUniqueID;
	private List<Appointment> appointmentList = new ArrayList<>(); {
		uniqueID = UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
	}
	
//this will let the us find any apt if needed
	private Appointment findAppointment(String appointmentID) throws Exception {
		int index = 0;
		while (index < appointmentList.size()) {
			if (appointmentID.equals(appointmentList.get(index).getappointmentID())) {
				return appointmentList.get(index);
			}
			index++;
		}
		throw new Exception("Unable to Process");
	}
	

	private String freshUniqueID() {
		return uniqueID = UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
	}
	
	protected List<Appointment> appointmentList() {
		return appointmentList;
	}
	
//now so the appointment service shall be able to add appointments with a unique appointment ID
	public void addAppointment() {
		Appointment appointment = new Appointment(freshUniqueID());
		appointmentList.add(appointment);
		
	}
	
	public void addAppointment(String appointmentID) {
		Appointment appointment = new Appointment(freshUniqueID(), appointmentID);
		appointmentList.add(appointment);
	}
	
	public void addAppointment(String appointmentID, String appointmentScript) {
		Appointment appointment = new Appointment(newUniqueID(), appointmentID, appointmentScript);
		appointmentList.add(appointment);
	}
		
//lastly so the appointment service shall be able to delete appointments per appointment ID        
	public void deleteAppointment(String appointmentID) throws Exception {
		appointmentList.remove(findAppointment(appointmentID));
	}


}
