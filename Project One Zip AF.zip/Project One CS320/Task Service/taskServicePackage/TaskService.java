package taskServicePackage;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import taskPackage.Task;

public class TaskService {

	private String uniqueID;
	private String freshUniqueID;
	private List<Task> taskList = new ArrayList<>(); {
		uniqueID = UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
	}
	

	private Task findTask(String taskID) throws Exception {
		int index = 0;
		while (index < taskList.size()) {
			if (taskID.equals(taskList.get(index).getTaskID())) {
				return taskList.get(index);
			}
			index++;
		}
		throw new Exception("Unable to Process");
	}
	

	private String freshUniqueID() {
		return uniqueID = UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
	}
	
	protected List<Task> taskList() {
		return taskList;
	}
	

	public void newTask() {
		Task task = new Task(freshUniqueID());
		taskList.add(task);
		
	}
	
	public void newTask(String taskName) {
		Task task = new Task(freshUniqueID(), taskName);
		taskList.add(task);
	}
	
	public void newTask(String taskName, String taskScript) {
		Task task = new Task(newUniqueID(), taskName, taskScript);
		taskList.add(task);
	}
		
	public void deleteTask(String taskID) throws Exception {
		taskList.remove(findTask(taskID));
	}
	
	
	public void updateTaskName(String taskID, String taskName) throws Exception {
		findTask(taskID).updateTaskName(taskName);
	}
	
	public void updateTaskScript(String taskID, String taskScript) throws Exception {
		findTask(taskID).updateTaskScript(taskScript);
	}

}
