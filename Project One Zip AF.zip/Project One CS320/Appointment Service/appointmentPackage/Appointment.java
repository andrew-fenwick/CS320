package appointmentPackage;

//these imports will allow date the function properly
import java.util.Date;
import java.util.ArrayList;
import java.util.Calendar;

public class Appointment {

//making sure to include any private component we'll need
    private String appointmentID;
    private int duration;
    private SimpleDateFormat form = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
    private Date appointmentDate;
    private String appointmentScript;
    

    public Appointment(String appointmentID, String appointmentID, String appointmentScript) {
    
    //so the apt ID is no more than 10  
        if(appointmentID == null || appointmentID.length()>10) {
            throw new IllegalArgumentException("Invalid appointment ID");
        }
       
        if (appointmentDate == null) {
            this.appointmentDate = new Date(2024, Calendar.JANUARY, 1);
        } else if (appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid Date - Please Choose Future Date");
        } else {
            this.appointmentDate = appointmentDate;
        }

    //keeping the description at 50 characters or less  
        if(appointmentScript == null || appointmentScript.length()>50) {
            throw new IllegalArgumentException("Invalid Description");
        }
    }
    
    
    public String appointmentID() {
        return appointmentID;
    }

    public Date appointmentDate() {
        return appointmentDate;
    }

    public String appointmentScript() {
        return appointmentScript;
    }

}



