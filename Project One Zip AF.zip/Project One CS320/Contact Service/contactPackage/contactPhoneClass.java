package contactPackage;


public class contactPhoneClass {
	
	private String phoneID;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String Address;
	

	public contactPhoneClass(String phoneID, String firstName, String lastName, String phoneNumber, String Address) {
		
		if(phoneID == null || phoneID.length()>10) {
            throw new IllegalArgumentException("Invalid Contact ID");
        }
        if(firstName == null || firstName.length()>10) {
            throw new IllegalArgumentException("Invalid First Name");
        }
        if(lastName == null || lastName.length()>10) {
            throw new IllegalArgumentException("Invalid Last Name");
        }
        if(phoneNumber == null || phoneNumber.length()>10) {
            throw new IllegalArgumentException("Invalid Phone Number");
        }
        if(Address == null || Address.length()>30) {
            throw new IllegalArgumentException("Invalid Addres");
        }
		
	}
	
	public String getPhoneID() {
        return phoneID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getAddress() {
        return Address;
    }

}


